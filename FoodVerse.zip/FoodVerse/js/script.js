/* ==========================================================================
   FoodVerse — script.js
   Core interactions: loader, nav, toasts, tabs, FAQ, countdown, ripple
   ========================================================================== */

window.FoodVerse = window.FoodVerse || {};

(function () {
  /* ---------------------------------------------------------------------
     Loading screen
  --------------------------------------------------------------------- */
  window.addEventListener('load', () => {
    const loader = document.getElementById('loader');
    if (!loader) return;
    setTimeout(() => loader.classList.add('hidden'), 600);
  });

  document.addEventListener('DOMContentLoaded', () => {
    /* ---------------------------------------------------------------------
       Scroll progress bar + sticky navbar
    --------------------------------------------------------------------- */
    const progress = document.getElementById('scroll-progress');
    const navbar = document.querySelector('.navbar');
    const backTop = document.querySelector('[data-back-top]');

    function onScroll() {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
      if (progress) progress.style.width = pct + '%';

      if (navbar) navbar.classList.toggle('scrolled', scrollTop > 40);
      if (backTop) backTop.classList.toggle('show', scrollTop > 480);
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    if (backTop) {
      backTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    }

    /* ---------------------------------------------------------------------
       Mobile hamburger menu
    --------------------------------------------------------------------- */
    const hamburger = document.querySelector('.hamburger');
    const mobileMenu = document.querySelector('.mobile-menu');

    if (hamburger && mobileMenu) {
      hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('open');
        mobileMenu.classList.toggle('open');
      });
      mobileMenu.querySelectorAll('a').forEach((link) =>
        link.addEventListener('click', () => {
          hamburger.classList.remove('open');
          mobileMenu.classList.remove('open');
        })
      );
    }

    /* ---------------------------------------------------------------------
       Ripple effect on buttons
    --------------------------------------------------------------------- */
    document.querySelectorAll('.btn').forEach((btn) => {
      btn.addEventListener('click', function (e) {
        const rect = btn.getBoundingClientRect();
        const ripple = document.createElement('span');
        const size = Math.max(rect.width, rect.height);
        ripple.className = 'ripple-el';
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = e.clientX - rect.left - size / 2 + 'px';
        ripple.style.top = e.clientY - rect.top - size / 2 + 'px';
        btn.appendChild(ripple);
        setTimeout(() => ripple.remove(), 650);
      });
    });

    /* ---------------------------------------------------------------------
       Toast notifications
    --------------------------------------------------------------------- */
    const toastEl = document.getElementById('toast');
    let toastTimeout;

    window.FoodVerse.showToast = function (message, type) {
      if (!toastEl) return;
      const icon = type === 'heart' ? '♥' : type === 'cart' ? '✓' : '✓';
      toastEl.innerHTML = `<span class="toast__icon">${icon}</span> ${message}`;
      toastEl.classList.add('show');
      clearTimeout(toastTimeout);
      toastTimeout = setTimeout(() => toastEl.classList.remove('show'), 2600);
    };

    /* ---------------------------------------------------------------------
       Food tabs (Popular / Trending / Best Sellers / Recommended)
    --------------------------------------------------------------------- */
    const tabButtons = document.querySelectorAll('.food-tab');
    const panels = document.querySelectorAll('.food-panel');

    tabButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-tab');
        tabButtons.forEach((b) => b.classList.remove('active'));
        panels.forEach((p) => p.classList.remove('active'));
        btn.classList.add('active');
        const panel = document.querySelector(`.food-panel[data-panel="${target}"]`);
        if (panel) panel.classList.add('active');
      });
    });

    /* ---------------------------------------------------------------------
       FAQ accordion
    --------------------------------------------------------------------- */
    document.querySelectorAll('.faq-item').forEach((item) => {
      const question = item.querySelector('.faq-item__q');
      const answer = item.querySelector('.faq-item__a');

      question.addEventListener('click', () => {
        const isActive = item.classList.contains('active');

        document.querySelectorAll('.faq-item').forEach((other) => {
          other.classList.remove('active');
          other.querySelector('.faq-item__a').style.maxHeight = null;
        });

        if (!isActive) {
          item.classList.add('active');
          answer.style.maxHeight = answer.scrollHeight + 'px';
        }
      });
    });

    /* ---------------------------------------------------------------------
       Countdown timers (Today's Special + Offers)
    --------------------------------------------------------------------- */
    document.querySelectorAll('[data-countdown]').forEach((wrap) => {
      const endTime = Date.now() + parseInt(wrap.getAttribute('data-countdown'), 10) * 1000;
      const dEl = wrap.querySelector('.cd-days');
      const hEl = wrap.querySelector('.cd-hours');
      const mEl = wrap.querySelector('.cd-mins');
      const sEl = wrap.querySelector('.cd-secs');

      function tick() {
        const diff = Math.max(endTime - Date.now(), 0);
        const days = Math.floor(diff / 86400000);
        const hours = Math.floor((diff % 86400000) / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);

        if (dEl) dEl.textContent = String(days).padStart(2, '0');
        if (hEl) hEl.textContent = String(hours).padStart(2, '0');
        if (mEl) mEl.textContent = String(mins).padStart(2, '0');
        if (sEl) sEl.textContent = String(secs).padStart(2, '0');

        if (diff > 0) requestAnimationFrame(() => setTimeout(tick, 1000));
      }
      tick();
    });

    /* ---------------------------------------------------------------------
       Hero typing animation
    --------------------------------------------------------------------- */
    const typeEl = document.querySelector('[data-typing]');
    if (typeEl) {
      const words = JSON.parse(typeEl.getAttribute('data-typing'));
      let wordIndex = 0;
      let charIndex = 0;
      let deleting = false;

      function typeLoop() {
        const currentWord = words[wordIndex];
        if (!deleting) {
          charIndex++;
          typeEl.textContent = currentWord.slice(0, charIndex);
          if (charIndex === currentWord.length) {
            deleting = true;
            setTimeout(typeLoop, 1400);
            return;
          }
        } else {
          charIndex--;
          typeEl.textContent = currentWord.slice(0, charIndex);
          if (charIndex === 0) {
            deleting = false;
            wordIndex = (wordIndex + 1) % words.length;
          }
        }
        setTimeout(typeLoop, deleting ? 45 : 95);
      }
      typeLoop();
    }

    /* ---------------------------------------------------------------------
       Newsletter form (demo)
    --------------------------------------------------------------------- */
    document.querySelectorAll('.newsletter-form').forEach((form) => {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const input = form.querySelector('input');
        if (input && input.value.trim()) {
          window.FoodVerse.showToast('Subscribed! Check your inbox 🎉');
          input.value = '';
        }
      });
    });
  });
})();
