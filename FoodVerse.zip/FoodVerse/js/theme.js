/* ==========================================================================
   FoodVerse — theme.js
   Handles dark / light mode toggle + persistence
   ========================================================================== */

(function () {
  const STORAGE_KEY = 'foodverse-theme';
  const root = document.documentElement;
  const toggleBtns = document.querySelectorAll('[data-theme-toggle]');

  function applyTheme(theme) {
    if (theme === 'dark') {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.removeAttribute('data-theme');
    }
    toggleBtns.forEach((btn) => btn.setAttribute('aria-pressed', theme === 'dark'));
  }

  function getPreferredTheme() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  // Apply immediately to avoid flash of wrong theme
  applyTheme(getPreferredTheme());

  document.addEventListener('DOMContentLoaded', () => {
    toggleBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        const current = root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
        const next = current === 'dark' ? 'light' : 'dark';
        applyTheme(next);
        localStorage.setItem(STORAGE_KEY, next);
      });
    });
  });
})();
