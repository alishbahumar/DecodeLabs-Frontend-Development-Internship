/* ==========================================================================
   FoodVerse — slider.js
   Auto-playing testimonial carousel with dot navigation
   ========================================================================== */

(function () {
  document.addEventListener('DOMContentLoaded', () => {
    const track = document.querySelector('[data-testimonial-track]');
    const dotsWrap = document.querySelector('[data-testimonial-dots]');
    if (!track || !dotsWrap) return;

    const slides = Array.from(track.children);
    let activeIndex = 0;
    let autoplayId = null;

    slides.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.className = 'slider-dot';
      dot.setAttribute('aria-label', 'Go to testimonial ' + (i + 1));
      if (i === 0) dot.classList.add('active');
      dot.addEventListener('click', () => goTo(i, true));
      dotsWrap.appendChild(dot);
    });

    const dots = Array.from(dotsWrap.children);

    function goTo(index, userTriggered) {
      activeIndex = (index + slides.length) % slides.length;
      const offset = -activeIndex * 100;
      track.style.transform = `translateX(${offset}%)`;
      dots.forEach((d, i) => d.classList.toggle('active', i === activeIndex));
      if (userTriggered) restartAutoplay();
    }

    function next() {
      goTo(activeIndex + 1, false);
    }

    function startAutoplay() {
      autoplayId = setInterval(next, 5000);
    }

    function restartAutoplay() {
      clearInterval(autoplayId);
      startAutoplay();
    }

    track.style.display = 'flex';
    track.style.transition = 'transform 0.6s cubic-bezier(0.65,0,0.35,1)';
    slides.forEach((slide) => {
      slide.style.flex = '0 0 100%';
    });

    startAutoplay();

    track.closest('.testimonial-slider-wrap').addEventListener('mouseenter', () => clearInterval(autoplayId));
    track.closest('.testimonial-slider-wrap').addEventListener('mouseleave', startAutoplay);
  });
})();
