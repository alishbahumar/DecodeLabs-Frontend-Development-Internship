/* ==========================================================================
   FoodVerse — wishlist.js
   Handles wishlist toggling, counter, and localStorage persistence
   ========================================================================== */

(function () {
  const STORAGE_KEY = 'foodverse-wishlist';

  function getWishlist() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function saveWishlist(list) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  }

  function updateWishlistCount() {
    const count = getWishlist().length;
    document.querySelectorAll('[data-wishlist-count]').forEach((el) => {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  function toggleWishlistItem(id, btn) {
    let list = getWishlist();
    const isActive = list.includes(id);

    if (isActive) {
      list = list.filter((item) => item !== id);
      btn.classList.remove('active');
    } else {
      list.push(id);
      btn.classList.add('active');
      window.FoodVerse && window.FoodVerse.showToast && window.FoodVerse.showToast('Added to wishlist', 'heart');
    }
    saveWishlist(list);
    updateWishlistCount();
  }

  document.addEventListener('DOMContentLoaded', () => {
    const wishlist = getWishlist();

    document.querySelectorAll('.food-card__wishlist').forEach((btn) => {
      const id = btn.getAttribute('data-food-id');
      if (id && wishlist.includes(id)) btn.classList.add('active');

      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleWishlistItem(id, btn);
      });
    });

    updateWishlistCount();
  });
})();
