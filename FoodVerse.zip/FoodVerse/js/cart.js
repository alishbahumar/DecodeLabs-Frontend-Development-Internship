/* ==========================================================================
   FoodVerse — cart.js
   Handles add-to-cart counter + localStorage persistence (home page demo)
   ========================================================================== */

(function () {
  const STORAGE_KEY = 'foodverse-cart';

  function getCart() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
  }

  function updateCartCount() {
    const cart = getCart();
    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    document.querySelectorAll('[data-cart-count]').forEach((el) => {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  function addToCart(id, name) {
    const cart = getCart();
    const existing = cart.find((item) => item.id === id);
    if (existing) {
      existing.qty += 1;
    } else {
      cart.push({ id, name, qty: 1 });
    }
    saveCart(cart);
    updateCartCount();
    window.FoodVerse && window.FoodVerse.showToast && window.FoodVerse.showToast(`${name} added to cart`, 'cart');
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.food-card__add').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const card = btn.closest('.food-card');
        const id = card ? card.getAttribute('data-food-id') : 'item';
        const name = card ? card.querySelector('.food-card__title').textContent : 'Item';
        addToCart(id, name);
      });
    });

    updateCartCount();
  });
})();
