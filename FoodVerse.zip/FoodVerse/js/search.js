/* ==========================================================================
   FoodVerse — search.js
   Live search suggestions for the navbar search field
   ========================================================================== */

(function () {
  const SEARCH_INDEX = [
    { name: 'Margherita Pizza', cat: 'Pizza', icon: '🍕' },
    { name: 'Smoky BBQ Burger', cat: 'Burger', icon: '🍔' },
    { name: 'Chicken Tikka BBQ', cat: 'BBQ', icon: '🍢' },
    { name: 'Chicken Karahi', cat: 'Pakistani', icon: '🍛' },
    { name: 'Beef Chow Mein', cat: 'Chinese', icon: '🍜' },
    { name: 'Creamy Alfredo Pasta', cat: 'Italian', icon: '🍝' },
    { name: 'Grilled Salmon', cat: 'Sea Food', icon: '🐟' },
    { name: 'Chicken Shawarma', cat: 'Arabian', icon: '🌯' },
    { name: 'Molten Chocolate Cake', cat: 'Desserts', icon: '🍰' },
    { name: 'Belgian Waffle Sundae', cat: 'Ice Cream', icon: '🍨' },
    { name: 'Quinoa Buddha Bowl', cat: 'Healthy Food', icon: '🥗' },
    { name: 'Vegan Buddha Wrap', cat: 'Vegan', icon: '🌱' },
    { name: 'Iced Mango Lassi', cat: 'Drinks', icon: '🥤' },
    { name: 'Pepperoni Feast Pizza', cat: 'Pizza', icon: '🍕' },
    { name: 'Classic Cheese Burger', cat: 'Burger', icon: '🍔' },
  ];

  document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.querySelector('[data-search-toggle]');
    const wrap = document.querySelector('.nav-search');
    const input = document.querySelector('.nav-search input');
    const resultsBox = document.querySelector('.nav-search__results');

    if (!toggleBtn || !wrap || !input || !resultsBox) return;

    toggleBtn.addEventListener('click', () => {
      wrap.classList.toggle('open');
      if (wrap.classList.contains('open')) {
        setTimeout(() => input.focus(), 200);
      } else {
        resultsBox.classList.remove('show');
      }
    });

    input.addEventListener('input', () => {
      const query = input.value.trim().toLowerCase();

      if (!query) {
        resultsBox.classList.remove('show');
        resultsBox.innerHTML = '';
        return;
      }

      const matches = SEARCH_INDEX.filter(
        (item) => item.name.toLowerCase().includes(query) || item.cat.toLowerCase().includes(query)
      ).slice(0, 6);

      if (matches.length === 0) {
        resultsBox.innerHTML = '<p class="nav-search__empty">No dishes found for "' + escapeHtml(query) + '"</p>';
      } else {
        resultsBox.innerHTML = matches
          .map(
            (item) =>
              `<a href="menu.html"><span>${item.icon}</span> ${escapeHtml(item.name)} <small style="margin-left:auto;color:var(--color-ink-30);font-size:11px;">${item.cat}</small></a>`
          )
          .join('');
      }
      resultsBox.classList.add('show');
    });

    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target)) {
        resultsBox.classList.remove('show');
      }
    });

    function escapeHtml(str) {
      const div = document.createElement('div');
      div.textContent = str;
      return div.innerHTML;
    }
  });
})();
